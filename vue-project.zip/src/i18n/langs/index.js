import en from './en'
import zh from './zh-cn'

export default {
    "en":en,
    "zh":zh
}