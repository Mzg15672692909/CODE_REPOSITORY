//申请商品
export const office = [
    {key:1,display_name:'计算器'},
    {key:2,display_name:'电脑'},
    {key:3,display_name:'加湿器'},
    {key:4,display_name:'打印机'},
    {key:5,display_name:'笔'},
]