import Vue from 'vue'

Vue.component(
    'myHello',{
        render(){
            return <h1>hello 1111</h1>
        }
    }
)

Vue.component(
    'myHello2',{
        render(){
            return <h1>hello 2222</h1>
        }
    }
)