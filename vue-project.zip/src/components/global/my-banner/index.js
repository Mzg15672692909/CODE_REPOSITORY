import myBanner from './layout'
export default myBanner