<template>
  <div>
    终审
  </div>
</template>

<script>
export default {
  data(){
    return {

    }
  },
  methods:{

  }
}
</script>


