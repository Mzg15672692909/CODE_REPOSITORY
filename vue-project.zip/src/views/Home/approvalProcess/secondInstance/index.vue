<template>
  <div>
    二审
  </div>
</template>

<script>
export default {
  data(){
    return {

    }
  },
  methods:{

  }
}
</script>


